import React from "react";
import "./HomePage.scss";

const HomePage = () => {
  return (
    <div className="homepage-contents">
      <h1>Hi, I'm Suman Mondal</h1>
      <p>A Web Developer!</p>
    </div>
  );
};

export default HomePage;
