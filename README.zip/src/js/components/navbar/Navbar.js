import React from "react";
import { Link } from "react-router-dom";
import { NAVBAR_CONFIG } from "./navbar-config";
import "./Navbar.scss";

const Navbar = ({ setCurrentTab, currentTab }) => {
  const navbarItems = () => {
    return NAVBAR_CONFIG.map((each) => {
      return (
        <li>
          <Link
            className={currentTab === each.url ? "selected-tab" : ""}
            to={each.url}
            onClick={() => setCurrentTab(each.url)}
          >
            {each.disp}
          </Link>
        </li>
      );
    });
  };
  return (
    <nav className="navbar">
      <ul>{navbarItems()}</ul>
    </nav>
  );
};

export default Navbar;
